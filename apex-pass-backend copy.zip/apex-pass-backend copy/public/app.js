(() => {
    'use strict';

    const $ = (selector) => document.querySelector(selector);
    const assetSelect = $('#asset_select');
    const customAsset = $('#custom_asset');
    const promptInput = $('#user_prompt');
    const chartSymbol = $('#chart_symbol');
    const chartContainer = $('#tradingview_chart');
    const overlay = $('#level_overlay');
    const chartEmpty = $('#chart_empty');
    const levelsFooter = $('#levels_footer');
    const form = $('#analysis_form');
    const submitButton = $('#analyze_button');
    const buttonLabel = $('#button_label');
    const output = $('#ai_output');
    const status = $('#data_status');
    const latency = $('#latency_status');
    const assetName = $('#asset_name');
    const assetSymbol = $('#asset_symbol');
    const assetPrice = $('#asset_price');
    const assetChange = $('#asset_change');
    const assetMeta = $('#asset_meta');
    const verdictValue = $('#verdict_value');
    const verdictConfidence = $('#verdict_confidence');
    const rrValue = $('#rr_value');
    const rrDirection = $('#rr_direction');
    const entryValue = $('#entry_value');
    const stopValue = $('#stop_value');
    const targetValue = $('#target_value');
    const sourceCount = $('#source_count');
    const volumeValue = $('#volume_value');
    const sentimentValue = $('#sentiment_value');
    const spreadValue = $('#spread_value');
    const marketNote = $('#market_note');
    const workspaceStatus = $('#workspace_status');
    const analysisView = $('#analysis_view');
    const structuresView = $('#structures_view');
    const tabs = [...document.querySelectorAll('[data-tab]')];

    const state = {
        widget: null,
        asset: 'ETH',
        levels: [],
        candleRange: null,
        socket: null,
        resizeObserver: null,
        widgetObserver: null,
        widgetLoadTimeout: null
    };

    function getAsset() {
        const selected = assetSelect.value === 'CUSTOM' ? customAsset.value : assetSelect.value;
        return selected.trim().toUpperCase();
    }

    function isValidAsset(asset) {
        return /^[A-Z0-9]{2,15}$/.test(asset);
    }

    function setStatus(message, nextState) {
        status.textContent = message;
        status.dataset.state = nextState;
        workspaceStatus.textContent = nextState === 'live' ? 'Live' : nextState === 'error' ? 'Unavailable' : 'Connecting';
    }

    function setLoading(isLoading) {
        submitButton.disabled = isLoading;
        submitButton.setAttribute('aria-busy', String(isLoading));
        buttonLabel.textContent = isLoading ? 'Analyzing market…' : 'Run APEX analysis';
    }

    function showError(message) {
        output.textContent = '';
        const error = document.createElement('p');
        error.className = 'output-error';
        error.textContent = message;
        output.append(error);
    }

    function formatCurrency(value) {
        const price = Number(value);
        if (!Number.isFinite(price) || price <= 0) return '—';
        return `$${price.toLocaleString('en-US', {
            minimumFractionDigits: price < 1 ? 4 : 2,
            maximumFractionDigits: price < 1 ? 6 : 2
        })}`;
    }

    function assetDisplayName(symbol) {
        return ({
            BTC: 'Bitcoin',
            ETH: 'Ethereum',
            SOL: 'Solana',
            TAO: 'Bittensor',
            ADA: 'Cardano',
            XRP: 'XRP',
            DOT: 'Polkadot'
        })[symbol] || symbol;
    }

    function updateAssetHeader(asset) {
        assetName.textContent = assetDisplayName(asset);
        assetSymbol.textContent = asset;
        assetPrice.textContent = '—';
        assetChange.textContent = '24h change unavailable';
        assetChange.className = '';
        assetMeta.textContent = 'Binance spot market · live context loads on analysis';
    }

    function renderSections(markdown) {
        const sections = [];
        for (const line of markdown.split(/\r?\n/)) {
            const heading = line.match(/^\s*(?:#{1,4}\s*)?(?:\*\*)?(?:([1-7])[.)]\s*)?([^:\n*]{2,90}):(?:\*\*)?\s*(.*)$/);
            if (heading) {
                sections.push({ title: heading[2].trim(), content: heading[3].trim() });
            } else if (sections.length) {
                sections[sections.length - 1].content += `${sections[sections.length - 1].content ? '\n' : ''}${line}`;
            }
        }
        if (!sections.length) {
            sections.push({ title: 'Analysis', content: markdown });
        }

        analysisView.replaceChildren();
        for (const section of sections) {
            const article = document.createElement('article');
            const heading = document.createElement('small');
            const paragraph = document.createElement('p');
            heading.textContent = section.title;
            paragraph.textContent = section.content.trim() || 'See the complete response below.';
            article.append(heading, paragraph);
            analysisView.append(article);
        }
        const verdict = sections[0]?.content || '';
        const verdictMatch = verdict.match(/\b(LONG|SHORT|NEUTRAL|NEUTRU|FĂRĂ DATE|NO DATA)\b/i);
        verdictValue.textContent = verdictMatch ? verdictMatch[0].toUpperCase() : 'REVIEW';
        verdictConfidence.textContent = 'Extracted from analysis';
        verdictValue.className = verdictValue.textContent === 'LONG'
            ? 'positive'
            : ['SHORT', 'FĂRĂ DATE', 'NO DATA'].includes(verdictValue.textContent)
                ? 'negative'
                : '';
    }

    function updateScenario(scenarios) {
        const qualified = scenarios?.long || scenarios?.short;
        if (!qualified) {
            rrValue.textContent = '—';
            rrDirection.textContent = 'No qualified setup';
            entryValue.textContent = '—';
            stopValue.textContent = '—';
            targetValue.textContent = '—';
            return;
        }
        rrValue.textContent = `1:${Number(qualified.risk_reward).toFixed(2)}`;
        rrDirection.textContent = `${qualified.direction.toUpperCase()} · minimum 1:3`;
        entryValue.textContent = formatCurrency(qualified.entry_usd);
        stopValue.textContent = formatCurrency(qualified.stop_loss_usd);
        targetValue.textContent = formatCurrency(qualified.take_profit_usd);
    }

    function updateMarketContext(result) {
        const market = result.date_sursa || {};
        const fundamentals = result.date_fundamentale_si_macro || market.date_fundamentale_si_macro || {};
        const validation = market.validare_pret_multi_sursa || {};
        const liquidity = fundamentals.lichiditate || {};
        const sentiment = fundamentals.sentiment_macro || {};
        const price = Number(market.media_piata_usd);
        const priceValidated = validation.validare_disponibila === true;

        if (market.moneda) updateAssetHeader(String(market.moneda).toUpperCase());
        assetMeta.textContent = priceValidated
            ? `${market.numar_surse_pret} independent price sources · aggregated reference`
            : 'Multi-source price validation unavailable · no reference price shown';
        if (priceValidated && Number.isFinite(price) && price > 0) {
            assetPrice.textContent = formatCurrency(price);
            assetChange.textContent = 'Validated aggregate reference';
            assetChange.className = '';
        } else if (!priceValidated) {
            assetPrice.textContent = '—';
            assetChange.textContent = 'Price not validated across sources';
            assetChange.className = '';
        }

        sourceCount.textContent = Number.isFinite(Number(market.numar_surse_pret))
            ? `${market.numar_surse_pret} / 3`
            : '—';
        const volume = fundamentals.volum_24h;
        volumeValue.textContent = volume && Number.isFinite(Number(volume.valoare))
            ? `${Number(volume.valoare).toLocaleString('en-US', { maximumFractionDigits: 0 })} ${volume.unitate || ''}`.trim()
            : '—';
        sentimentValue.textContent = Number.isFinite(Number(sentiment.indice))
            ? `${sentiment.indice} · ${sentiment.clasificare || ''}`.trim()
            : '—';
        spreadValue.textContent = Number.isFinite(Number(liquidity.spread_procent))
            ? `${Number(liquidity.spread_procent).toFixed(4)}%`
            : '—';
        marketNote.textContent = market.anomalie_exchange || 'Figures are shown only when present in the backend response.';
        updateScenario(market.niveluri_tehnice?.scenarii_calificate);
    }

    function renderStructures(drawings) {
        const structures = drawings.filter((drawing) =>
            /^(fvg_|order_block_|liquidity_sweep_)/.test(drawing.categoria || '')
        );
        structuresView.replaceChildren();
        if (!structures.length) {
            const empty = document.createElement('p');
            empty.textContent = 'No qualifying FVG, sweep, or order-block structures were returned.';
            structuresView.append(empty);
            return;
        }
        for (const drawing of structures) {
            const item = document.createElement('article');
            const heading = document.createElement('small');
            const label = document.createElement('p');
            heading.textContent = `${drawing.tip_forma.replace('_', ' ')} · ${drawing.interval || '—'}`;
            heading.style.color = /^#[\da-f]{6}$/i.test(drawing.culoare_hex || '')
                ? drawing.culoare_hex
                : '';
            label.textContent = drawing.eticheta || drawing.categoria;
            item.append(heading, label);
            structuresView.append(item);
        }
    }

    function initializeWidget(asset) {
        state.asset = asset;
        updateAssetHeader(asset);
        const symbol = `BINANCE:${asset}USDT`;
        chartSymbol.textContent = symbol;
        chartEmpty.hidden = false;
        overlay.replaceChildren();
        state.levels = [];
        state.candleRange = null;
        levelsFooter.textContent = 'No AI-detected levels yet · Run an analysis to draw zones';

        state.widgetObserver?.disconnect();
        state.widgetObserver = null;
        window.clearTimeout(state.widgetLoadTimeout);
        chartContainer.replaceChildren();
        state.widget = null;

        if (typeof window.TradingView?.widget !== 'function') {
            chartEmpty.textContent = 'TradingView chart could not be loaded. Check your connection and reload.';
            setStatus('Chart unavailable', 'error');
            return;
        }

        try {
            state.widget = new window.TradingView.widget({
                autosize: true,
                symbol,
                interval: '240',
                timezone: 'Etc/UTC',
                theme: 'dark',
                style: '1',
                locale: 'en',
                enable_publishing: false,
                allow_symbol_change: false,
                hide_side_toolbar: true,
                hide_top_toolbar: false,
                save_image: false,
                container_id: 'tradingview_chart',
                studies: []
            });

            const revealChart = () => {
                chartEmpty.hidden = true;
                drawLevels();
            };
            const watchForIframe = () => {
                const iframe = chartContainer.querySelector('iframe');
                if (!iframe) return false;
                iframe.addEventListener('load', revealChart, { once: true });
                return true;
            };
            if (!watchForIframe()) {
                state.widgetObserver = new MutationObserver(() => {
                    if (watchForIframe()) {
                        state.widgetObserver?.disconnect();
                        state.widgetObserver = null;
                    }
                });
                state.widgetObserver.observe(chartContainer, { childList: true, subtree: true });
            }
            state.widgetLoadTimeout = window.setTimeout(() => {
                if (chartContainer.querySelector('iframe')) revealChart();
                else {
                    chartEmpty.textContent = 'TradingView chart did not load. Check your connection and reload.';
                    setStatus('Chart unavailable', 'error');
                }
            }, 10000);
        } catch (error) {
            chartEmpty.textContent = 'TradingView chart failed to initialize.';
            setStatus('Chart unavailable', 'error');
            console.error('TradingView widget initialization failed:', error);
        }

        connectMarketFeed(asset);
        loadCandleRange(asset);
    }

    function connectMarketFeed(asset) {
        if (state.socket) {
            state.socket.close();
            state.socket = null;
        }
        if (!('WebSocket' in window)) {
            setStatus('WebSocket unavailable', 'error');
            return;
        }

        const stream = `${asset.toLowerCase()}usdt@ticker`;
        try {
            const socket = new WebSocket(`wss://stream.binance.com:9443/ws/${stream}`);
            state.socket = socket;
            socket.addEventListener('open', () => {
                if (state.socket === socket) setStatus('Live Cache / WebSocket', 'live');
            });
            socket.addEventListener('message', (event) => {
                if (state.socket !== socket) return;
                try {
                    const update = JSON.parse(event.data);
                    const close = Number(update?.c);
                    if (Number.isFinite(close) && close > 0) {
                        assetPrice.textContent = formatCurrency(close);
                        const change = Number(update?.P);
                        if (Number.isFinite(change)) {
                            assetChange.textContent = `${change >= 0 ? '+' : ''}${change.toFixed(2)}% · Binance 24h`;
                            assetChange.className = change >= 0 ? 'positive' : 'negative';
                        }
                        setStatus('Binance ticker live', 'live');
                    }
                } catch (error) {
                    console.warn('Unable to parse market feed update:', error);
                }
            });
            socket.addEventListener('error', () => {
                if (state.socket === socket) setStatus('Market feed error', 'error');
            });
            socket.addEventListener('close', () => {
                if (state.socket === socket) setStatus('Market feed disconnected', 'error');
            });
        } catch (error) {
            setStatus('Market feed unavailable', 'error');
            console.error('Market feed connection failed:', error);
        }
    }

    async function loadCandleRange(asset) {
        try {
            const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${encodeURIComponent(asset)}USDT&interval=4h&limit=200`);
            if (!response.ok) throw new Error(`Market data request failed (${response.status}).`);
            const candles = await response.json();
            if (state.asset !== asset) return;
            const prices = candles.flatMap((candle) => [Number(candle[2]), Number(candle[3])]).filter(Number.isFinite);
            if (!prices.length) throw new Error('Market data did not contain valid prices.');
            const minimum = Math.min(...prices);
            const maximum = Math.max(...prices);
            const padding = (maximum - minimum) * 0.06 || maximum * 0.01;
            state.candleRange = { min: minimum - padding, max: maximum + padding };
            drawLevels();
        } catch (error) {
            if (state.asset !== asset) return;
            setStatus('Market data unavailable', 'error');
            console.error('Unable to load chart price range:', error);
        }
    }

    function formatPrice(price) {
        return price.toLocaleString('en-US', {
            minimumFractionDigits: price < 1 ? 4 : 2,
            maximumFractionDigits: price < 1 ? 6 : 2
        });
    }

    function drawLevels() {
        const bounds = chartContainer.getBoundingClientRect();
        const width = bounds.width;
        const height = bounds.height;
        overlay.setAttribute('viewBox', `0 0 ${width} ${height}`);
        overlay.replaceChildren();
        if (!width || !height || !state.candleRange || !state.levels.length) return;

        const { min, max } = state.candleRange;
        const plotTop = 34;
        const plotBottom = height - 40;
        const plotRight = width - 72;
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');

        state.levels.forEach((level) => {
            const low = Number(level.pret_minim);
            const high = Number(level.pret_maxim);
            if (!Number.isFinite(low) || !Number.isFinite(high) || low <= 0 || high <= 0 || high < min || low > max) return;
            const isSupport = level.categoria?.startsWith('support') || level.tip === 'support';
            const defaultColor = isSupport ? '#00F3B7' : '#FF3B69';
            const color = /^#[\da-f]{6}$/i.test(level.culoare_hex || level.culore || '')
                ? level.culoare_hex || level.culore
                : defaultColor;
            const yForPrice = (price) => plotBottom - ((price - min) / (max - min)) * (plotBottom - plotTop);
            const yTop = Math.max(plotTop, yForPrice(Math.min(high, max)));
            const yBottom = Math.min(plotBottom, yForPrice(Math.max(low, min)));
            const isScenario = level.tip_forma === 'vector' || level.tip_forma === 'arrow';
            const isCallout = level.tip_forma === 'callout_badge';
            const isZone = level.tip_forma === 'box' && !isCallout;

            if (isScenario) {
                const entry = Number(level.entry_usd ?? level.coordonate?.y1_usd);
                const target = Number(level.take_profit_usd ?? level.coordonate?.y2_usd);
                if (![entry, target].every((price) => Number.isFinite(price) && price >= min && price <= max)) return;
                const x1 = Math.max(0, plotRight * 0.68);
                const x2 = Math.max(x1 + 1, plotRight);
                const path = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                path.setAttribute('x1', String(x1));
                path.setAttribute('x2', String(x2));
                path.setAttribute('y1', String(yForPrice(entry)));
                path.setAttribute('y2', String(yForPrice(target)));
                path.setAttribute('stroke', color);
                path.setAttribute('stroke-width', '2');
                path.setAttribute('stroke-dasharray', '6 4');
                path.setAttribute('marker-end', 'url(#scenario-arrow)');
                group.append(path);
                return;
            }

            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', isCallout ? String(Math.max(0, plotRight - 190)) : '0');
            line.setAttribute('x2', String(Math.max(0, plotRight)));
            line.setAttribute('y1', String(yForPrice((low + high) / 2)));
            line.setAttribute('y2', String(yForPrice((low + high) / 2)));
            line.setAttribute('stroke', color);
            line.setAttribute('stroke-width', level.interval === 'all-time' ? '1.5' : '1');
            line.setAttribute('stroke-dasharray', level.tip_forma === 'line' || level.interval === 'all-time' ? '5 4' : '3 4');
            line.setAttribute('opacity', '.78');
            group.append(line);

            if (isZone && high - low > 0 && yBottom > yTop) {
                const band = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                band.setAttribute('x', String(Math.max(0, plotRight * 0.18)));
                band.setAttribute('y', String(yTop));
                band.setAttribute('width', String(Math.max(0, plotRight * 0.82)));
                band.setAttribute('height', String(yBottom - yTop));
                band.setAttribute('fill', color);
                band.setAttribute('opacity', '.07');
                if (level.animat === true) {
                    const animation = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
                    animation.setAttribute('attributeName', 'opacity');
                    animation.setAttribute('values', '.04;.12;.04');
                    animation.setAttribute('dur', '2.4s');
                    animation.setAttribute('repeatCount', 'indefinite');
                    band.append(animation);
                }
                group.insertBefore(band, line);
            }

            const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            label.setAttribute('x', String(Math.max(6, plotRight - 7)));
            label.setAttribute('y', String(yForPrice((low + high) / 2) - 5));
            label.setAttribute('text-anchor', 'end');
            label.setAttribute('fill', color);
            label.setAttribute('stroke', '#0A0E17');
            label.setAttribute('stroke-width', '3');
            label.setAttribute('paint-order', 'stroke');
            label.setAttribute('font-family', 'DM Mono, monospace');
            label.setAttribute('font-size', '10');
            label.textContent = `${level.eticheta || (isSupport ? 'Support' : 'Resistance')} · $${formatPrice((low + high) / 2)}`;
            if (isCallout) {
                label.setAttribute('x', String(Math.max(6, plotRight - 8)));
                label.setAttribute('text-anchor', 'end');
                label.setAttribute('font-size', '9');
            }
            group.append(label);
        });
        const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
        marker.setAttribute('id', 'scenario-arrow');
        marker.setAttribute('markerWidth', '8');
        marker.setAttribute('markerHeight', '8');
        marker.setAttribute('refX', '6');
        marker.setAttribute('refY', '3');
        marker.setAttribute('orient', 'auto');
        const arrowHead = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        arrowHead.setAttribute('d', 'M0,0 L0,6 L7,3 z');
        arrowHead.setAttribute('fill', 'context-stroke');
        marker.append(arrowHead);
        defs.append(marker);
        overlay.append(defs);
        overlay.append(group);
    }

    function validateDrawings(drawings) {
        if (!Array.isArray(drawings)) return [];
        return drawings.filter((drawing) => {
            if (!drawing || !['box', 'line', 'vector', 'arrow', 'callout_badge'].includes(drawing.tip_forma)) return false;
            const low = Number(drawing.pret_minim ?? drawing.coordonate?.y_usd ?? drawing.coordonate?.y1_usd);
            const high = Number(drawing.pret_maxim ?? drawing.coordonate?.y_usd ?? drawing.coordonate?.y2_usd ?? low);
            return Number.isFinite(low) && Number.isFinite(high) && low > 0 && high >= low;
        });
    }

    async function requestAnalysis(event) {
        event.preventDefault();
        const coin = getAsset();
        if (!isValidAsset(coin)) {
            showError('Enter a valid symbol using 2–15 letters or numbers.');
            customAsset.focus();
            return;
        }
        if (assetSelect.value === 'CUSTOM' && coin !== state.asset) initializeWidget(coin);

        setLoading(true);
        latency.textContent = 'Latency: —';
        const startedAt = performance.now();
        try {
            const response = await fetch('/api/apex/analiza', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    coin,
                    promptUtilizator: promptInput.value.trim()
                }),
                signal: AbortSignal.timeout(90000)
            });

            let result;
            try {
                result = await response.json();
            } catch {
                throw new Error(`The analysis service returned an invalid response (${response.status}).`);
            }
            if (!response.ok) {
                throw new Error(result?.error || result?.eroare || `Analysis request failed (${response.status}).`);
            }
            if (typeof result?.analiza_ai !== 'string' || !result.analiza_ai.trim()) {
                throw new Error('The analysis response did not include an AI analysis.');
            }

            renderSections(result.analiza_ai);
            updateMarketContext(result);
            state.levels = validateDrawings(result.desene_grafic);
            renderStructures(state.levels);
            drawLevels();
            levelsFooter.textContent = state.levels.length
                ? `${state.levels.length} validated drawings · overlays require a loaded market price range`
                : 'Analysis returned no drawable levels or structures';
            latency.textContent = `Latency: ${Math.round(performance.now() - startedAt)} ms`;
        } catch (error) {
            const message = error.name === 'TimeoutError'
                ? 'The analysis request timed out. Please try again.'
                : error.name === 'TypeError'
                    ? 'Unable to reach the analysis service. Check the connection and try again.'
                    : error.message || 'Analysis failed unexpectedly. Please try again.';
            showError(message);
            latency.textContent = `Latency: ${Math.round(performance.now() - startedAt)} ms`;
            console.error('Analysis request failed:', error);
        } finally {
            setLoading(false);
        }
    }

    assetSelect.addEventListener('change', () => {
        const isCustom = assetSelect.value === 'CUSTOM';
        customAsset.hidden = !isCustom;
        if (isCustom) {
            customAsset.focus();
            return;
        }
        initializeWidget(getAsset());
    });

    customAsset.addEventListener('change', () => {
        const asset = getAsset();
        if (!isValidAsset(asset)) {
            showError('Enter a valid symbol using 2–15 letters or numbers.');
            return;
        }
        initializeWidget(asset);
    });

    document.querySelectorAll('[data-prompt]').forEach((button) => {
        button.addEventListener('click', () => {
            promptInput.value = button.dataset.prompt;
            promptInput.focus();
        });
    });

    tabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            const showStructures = tab.dataset.tab === 'structures';
            analysisView.hidden = showStructures;
            structuresView.hidden = !showStructures;
            tabs.forEach((item) => {
                const selected = item === tab;
                item.classList.toggle('active', selected);
                item.setAttribute('aria-selected', String(selected));
            });
        });
    });

    form.addEventListener('submit', requestAnalysis);
    state.resizeObserver = new ResizeObserver(drawLevels);
    state.resizeObserver.observe(chartContainer);
    updateAssetHeader(state.asset);
    initializeWidget(state.asset);
})();
